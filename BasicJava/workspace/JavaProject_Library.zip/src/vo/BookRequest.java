package vo;

public class BookRequest {

}
