package vo;

public class Room {

}
