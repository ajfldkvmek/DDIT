package vo;

public class Book {

}
