package vo;

public class Event {

}
