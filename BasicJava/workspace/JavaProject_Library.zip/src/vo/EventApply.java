package vo;

public class EventApply {

}
