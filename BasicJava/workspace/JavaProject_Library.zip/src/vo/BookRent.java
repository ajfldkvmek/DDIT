package vo;

public class BookRent {

}
