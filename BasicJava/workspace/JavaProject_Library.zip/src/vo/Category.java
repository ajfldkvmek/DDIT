package vo;

public class Category {

}
