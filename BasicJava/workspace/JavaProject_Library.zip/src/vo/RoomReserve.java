package vo;

public class RoomReserve {

}
