package vo;

import lombok.Data;

@Data
public class Admin {
	 private String ticket;
	 private int sit_num;
	 private int no;
}
