package service;

public class RoomService {

}
