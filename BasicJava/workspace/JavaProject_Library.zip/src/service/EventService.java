package service;

public class EventService {

}
