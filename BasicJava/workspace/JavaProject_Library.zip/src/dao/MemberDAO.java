package dao;

public class MemberDAO {

}
