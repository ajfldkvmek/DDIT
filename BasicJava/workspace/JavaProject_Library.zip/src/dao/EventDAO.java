package dao;

public class EventDAO {

}
